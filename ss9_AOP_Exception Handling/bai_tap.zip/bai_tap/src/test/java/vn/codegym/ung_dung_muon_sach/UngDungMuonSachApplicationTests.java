package vn.codegym.ung_dung_muon_sach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UngDungMuonSachApplicationTests {

    @Test
    void contextLoads() {
    }

}
