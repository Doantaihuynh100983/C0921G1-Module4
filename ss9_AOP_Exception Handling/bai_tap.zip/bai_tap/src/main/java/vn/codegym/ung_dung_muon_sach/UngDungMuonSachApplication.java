package vn.codegym.ung_dung_muon_sach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UngDungMuonSachApplication {

    public static void main(String[] args) {
        SpringApplication.run(UngDungMuonSachApplication.class, args);
    }

}
